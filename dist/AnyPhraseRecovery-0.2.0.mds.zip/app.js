// AnyPhraseRecovery — sweep funds out of a compromised webWallet seed and restore
// the host node back to its original state. Vanilla JS, no build step.
//
// Architecture (v0.2):
//   1. SNAPSHOT — back up the host node's full state with a random password,
//      and force the user to write the original seed phrase on paper.
//   2. POSSESS  — megammrsync the compromised seed onto this node.
//   3. SWEEP    — send all recovered balances to the host node's existing address
//      (which is still the user's; only the seed has been temporarily borrowed).
//   4. RESTORE  — restoresync from the snapshot. The host's original seed is back.
//
// Failure-mode insurance: if the restore step fails, the user has TWO independent
// paths back to normal — the .bak file + password (shown in step 1), or the
// original 24-word seed they wrote on paper (also in step 1).

// ----- Config -----
const HOSTS = [
  "eurobuddha.com:9001",
  "spartacusrex.com:9001",
  "minimammr.com:9001",
  "megammr.minima.global:9001",
];
const KEYUSES = 2500;
const MEGAMMR_FILE_URL = "https://eurobuddha.com/mega.mmr";
const MEGAMMR_LOCAL_FILENAME = "mega.mmr";

// ----- State -----
const state = {
  // host snapshot
  hostMx: null,           // host node's existing default address (sweep target)
  hostSeed: null,         // host's original 24-word seed (shown for paper backup)
  backupFile: null,       // filename of the .bak in the Minima data folder
  backupPassword: null,   // random alphanumeric password for the .bak
  // compromised wallet
  compromisedSeed: null,  // normalized lowercase
  // sync
  selectedHost: null,
  importedAddresses: [],  // post-resync, default wallet addresses (destination guard)
  // sweep
  customDest: null,       // override Mx if user picks Advanced
  balances: [],           // [{tokenid, sendable, name}]
  swept: false,
  // restore
  restored: false,
};

// ============================================================================
// Helpers
// ============================================================================

function $(id) { return document.getElementById(id); }

function setStatus(elId, text, kind) {
  const el = $(elId);
  if (!el) return;
  el.textContent = text || "";
  el.className = "status" + (kind ? " " + kind : "");
}

function flashStatus(elId, text, kind) {
  const el = $(elId);
  if (!el) return;
  const prev = el.textContent;
  setStatus(elId, text, kind || "ok");
  setTimeout(() => { if (el.textContent === text) setStatus(elId, prev); }, 1600);
}

function copyText(text) {
  if (!text) return Promise.resolve(false);
  if (navigator.clipboard && navigator.clipboard.writeText) {
    return navigator.clipboard.writeText(text).then(() => true).catch(() => fallbackCopy(text));
  }
  return Promise.resolve(fallbackCopy(text));
}

function fallbackCopy(text) {
  const ta = document.createElement("textarea");
  ta.value = text;
  ta.style.position = "fixed";
  ta.style.left = "-9999px";
  document.body.appendChild(ta);
  ta.select();
  let ok = false;
  try { ok = document.execCommand("copy"); } catch (e) { ok = false; }
  document.body.removeChild(ta);
  return ok;
}

function cmd(c) {
  return new Promise((resolve, reject) => {
    MDS.cmd(c, (res) => {
      if (res && res.status) return resolve(res);
      reject(new Error((res && res.error) || ("command failed: " + (c.split(" ")[0] || c))));
    });
  });
}

function show(stepId) {
  document.querySelectorAll(".step").forEach(s => s.classList.remove("active"));
  const el = $("step-" + stepId);
  if (el) el.classList.add("active");
  window.scrollTo(0, 0);
}

function showTab(name) {
  document.querySelectorAll(".tab").forEach(t =>
    t.classList.toggle("active", t.dataset.tab === name));
  document.querySelectorAll(".tab-panel").forEach(p =>
    p.classList.toggle("active", p.id === "tab-" + name));
}

// Validation
function validMx(s) { return /^M[xX][0-9A-Za-z]{57,68}$/.test(s); }
function isReasonableSeed(s) {
  const words = s.trim().toLowerCase().split(/\s+/);
  if (words.length !== 24) return false;
  return words.every(w => /^[a-z]+$/.test(w));
}
function isHostString(s) { return /^[\w.-]+:\d+$/.test(s); }

// Cryptographically-strong random password (alphanumeric only — backup docs require it)
function genPassword(len) {
  len = len || 20;
  // omit easily-confused chars to make handwritten transcription reliable
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789";
  const buf = new Uint8Array(len);
  if (window.crypto && window.crypto.getRandomValues) {
    window.crypto.getRandomValues(buf);
  } else {
    for (let i = 0; i < len; i++) buf[i] = Math.floor(Math.random() * 256);
  }
  let out = "";
  for (let i = 0; i < len; i++) out += chars[buf[i] % chars.length];
  return out;
}

function tokenName(b) {
  if (!b) return "?";
  if (b.tokenid === "0x00") return "MINIMA";
  const tok = b.token;
  if (tok && tok.name) {
    if (typeof tok.name === "object" && tok.name.name) return String(tok.name.name);
    if (typeof tok.name === "string") return tok.name;
  }
  return (b.tokenid || "?").slice(0, 12) + "…";
}

// ============================================================================
// STEP 0 — Welcome
// ============================================================================

function onWelcomeStart() {
  show("snapshot");
  // Reset/clear any prior state on the snapshot screen
  state.backupFile = null;
  state.backupPassword = null;
  $("snap-backup-info").hidden = true;
  $("snap-paper-check").checked = false;
  $("snap-pw-check").checked = false;
  $("snap-backup-btn").disabled = true;
  $("snap-continue-btn").disabled = true;
  setStatus("snap-backup-status", "");
  $("snap-mx").textContent = "loading…";
  $("snap-seed").innerHTML = "<div class=\"hint\">Reading this node's seed and address…</div>";
  $("snap-verify-prompts").innerHTML = "";

  loadSnapshotData()
    .then(() => {
      startVerify();
      updateSnapshotEnabled();
    })
    .catch(e => {
      setStatus("snap-backup-status", "Failed to read this node's seed: " + e.message +
        ". If this node has a password-locked vault, unlock it from the terminal first (vault action:passwordunlock password:…), then reload this dapp.", "err");
    });
}

// ============================================================================
// STEP 1 — Snapshot (paper seed + .bak backup)
// ============================================================================

async function loadSnapshotData() {
  const v = await cmd("vault");
  const vr = v.response || {};
  state.hostSeed = (vr.phrase || vr.seedphrase || vr.seed || "").trim();
  if (!state.hostSeed) throw new Error("vault returned no seed");

  const a = await cmd("getaddress");
  const ar = a.response || {};
  state.hostMx = ar.miniaddress || ar.address || "";
  if (!state.hostMx) throw new Error("getaddress returned no address");

  renderSnapshotSeed();
}

function renderSnapshotSeed() {
  $("snap-mx").textContent = state.hostMx;
  const words = state.hostSeed.trim().split(/\s+/);
  const grid = $("snap-seed");
  grid.innerHTML = "";
  words.forEach((w, i) => {
    const wrap = document.createElement("div");
    wrap.className = "seed-word";
    const num = document.createElement("span");
    num.className = "num";
    num.textContent = (i + 1) + ".";
    const ww = document.createElement("span");
    ww.className = "w";
    ww.textContent = w;
    wrap.appendChild(num);
    wrap.appendChild(ww);
    grid.appendChild(wrap);
  });
}

function startVerify() {
  const words = state.hostSeed.trim().split(/\s+/);
  if (words.length !== 24) {
    setStatus("snap-backup-status", "Unexpected seed length (" + words.length + " words); cannot verify.", "err");
    return;
  }
  const idxs = new Set();
  while (idxs.size < 3) idxs.add(Math.floor(Math.random() * 24));
  const sorted = Array.from(idxs).sort((a, b) => a - b);

  const grid = $("snap-verify-prompts");
  grid.innerHTML = "";
  sorted.forEach(i => {
    const row = document.createElement("div");
    row.className = "verify-row";
    const lbl = document.createElement("label");
    lbl.textContent = "Word #" + (i + 1);
    const input = document.createElement("input");
    input.type = "text";
    input.dataset.idx = String(i);
    input.autocomplete = "off";
    input.autocapitalize = "none";
    input.autocorrect = "off";
    input.spellcheck = false;
    input.addEventListener("input", updateSnapshotEnabled);
    row.appendChild(lbl);
    row.appendChild(input);
    grid.appendChild(row);
  });
}

function updateSnapshotEnabled() {
  // Phase 1 — Run-backup is enabled iff verify words match + paper-check ticked
  const words = (state.hostSeed || "").trim().toLowerCase().split(/\s+/);
  const inputs = document.querySelectorAll("#snap-verify-prompts input");
  let allCorrect = inputs.length > 0;
  inputs.forEach(inp => {
    const want = words[Number(inp.dataset.idx)];
    const got = (inp.value || "").trim().toLowerCase();
    const row = inp.closest(".verify-row");
    if (!got) {
      row.classList.remove("ok", "err");
      allCorrect = false;
      return;
    }
    if (got === want) {
      row.classList.add("ok");
      row.classList.remove("err");
    } else {
      row.classList.add("err");
      row.classList.remove("ok");
      allCorrect = false;
    }
  });
  const paperOk = $("snap-paper-check").checked;
  const canBackup = allCorrect && paperOk && !!state.hostSeed;
  // Don't re-enable if backup already ran successfully
  if (!state.backupFile) {
    $("snap-backup-btn").disabled = !canBackup;
  }

  // Phase 2 — Continue is enabled iff backup completed AND password-check ticked
  const backupDone = !!state.backupFile && !!state.backupPassword;
  const pwOk = $("snap-pw-check").checked;
  $("snap-continue-btn").disabled = !(backupDone && pwOk);
}

async function onSnapBackup() {
  $("snap-backup-btn").disabled = true;
  setStatus("snap-backup-status", "Running backup — moment please…");
  try {
    const pw = genPassword(20);
    const file = "anyphrase-" + Date.now() + ".bak";
    await cmd("backup file:" + file + " password:" + pw);
    state.backupFile = file;
    state.backupPassword = pw;
    $("snap-backup-info").hidden = false;
    $("snap-backup-file").textContent = file + "  (in your Minima data folder)";
    $("snap-backup-password").textContent = pw;
    setStatus("snap-backup-status", "Backup complete. Write the password down before continuing.", "ok");
    updateSnapshotEnabled();
  } catch (e) {
    setStatus("snap-backup-status", "Backup failed: " + e.message + ". You cannot proceed without a snapshot.", "err");
    $("snap-backup-btn").disabled = false;
  }
}

// ============================================================================
// STEP 2 — Paste compromised seed
// ============================================================================

function onSeedContinue() {
  const raw = ($("seed-input").value || "").trim();
  if (!isReasonableSeed(raw)) {
    setStatus("seed-status", "Expected exactly 24 words separated by spaces, lowercase letters only.", "err");
    return;
  }
  // normalize: lowercase + collapse whitespace — BIP-39 word lists are lowercase
  state.compromisedSeed = raw.toLowerCase().split(/\s+/).join(" ");
  setStatus("seed-status", "");
  setupHostStep();
  show("sync");
}

// ============================================================================
// STEP 3 — Pick host + run megammrsync
// ============================================================================

function setupHostStep() {
  const list = $("host-list");
  list.innerHTML = "";
  HOSTS.forEach(h => {
    const li = document.createElement("li");
    li.textContent = h;
    list.appendChild(li);
  });
  state.selectedHost = null;
  rotateHost();
  $("sync-log").textContent = "";
  $("sync-run-btn").disabled = false;
  setStatus("sync-status", "");
}

function rotateHost() {
  const candidates = HOSTS.filter(h => h !== state.selectedHost);
  state.selectedHost = candidates[Math.floor(Math.random() * candidates.length)];
  renderSelectedHost();
}

function renderSelectedHost() {
  $("selected-host").textContent = state.selectedHost || "—";
  document.querySelectorAll("#host-list li").forEach(li => {
    li.classList.toggle("selected", li.textContent === state.selectedHost);
  });
}

function onCustomHostSet() {
  const v = ($("custom-host-input").value || "").trim();
  if (!isHostString(v)) {
    setStatus("sync-status", "Custom host should look like host.example.com:9001", "err");
    return;
  }
  state.selectedHost = v;
  renderSelectedHost();
  setStatus("sync-status", "Using custom host: " + v, "warn");
}

function appendSyncLog(line) {
  const el = $("sync-log");
  el.textContent += line + "\n";
  el.scrollTop = el.scrollHeight;
}

async function onRunSync() {
  $("sync-run-btn").disabled = true;
  setStatus("sync-status", "Running megammrsync against " + state.selectedHost + " — this can take 1–2 minutes…");
  try {
    const phrase = state.compromisedSeed.replace(/"/g, '\\"');
    const c = "megammrsync action:resync host:" + state.selectedHost +
              ' phrase:"' + phrase + '"' +
              " anyphrase:true keyuses:" + KEYUSES;
    appendSyncLog("> " + c.replace(/phrase:"[^"]*"/, 'phrase:"<hidden>"'));
    const r = await cmd(c);
    appendSyncLog(JSON.stringify(r.response || r, null, 2));
    setStatus("sync-status", "Sync complete. Loading balance…", "ok");
    await loadBalanceAndImportedAddresses();
    setupSweep();
    show("sweep");
  } catch (e) {
    appendSyncLog("ERROR: " + e.message);
    setStatus("sync-status", 'Sync failed: ' + e.message + '. Click "Try a different host", then "Run megammrsync" again.', "err");
    $("sync-run-btn").disabled = false;
  }
}

// Re-throws on `scripts` failure — we will not silently bypass the destination guard.
async function loadBalanceAndImportedAddresses() {
  const sR = await cmd("scripts");
  const arr = Array.isArray(sR.response) ? sR.response : [];
  state.importedAddresses = arr.filter(s => s && s.miniaddress).map(s => s.miniaddress);

  const bR = await cmd("balance");
  const bArr = Array.isArray(bR.response) ? bR.response : [];
  state.balances = bArr
    .map(b => ({
      tokenid: b.tokenid,
      sendable: b.sendable || b.confirmed || "0",
      confirmed: b.confirmed,
      name: tokenName(b),
    }))
    .filter(b => parseFloat(b.sendable) > 0);
}

// ============================================================================
// STEP 4 — Sweep
// ============================================================================

function getDestination() {
  return state.customDest || state.hostMx;
}

function setupSweep() {
  const dest = getDestination();
  $("sweep-dest").textContent = dest;

  const root = $("sweep-balance");
  root.innerHTML = "";
  if (state.balances.length === 0) {
    const row = document.createElement("div");
    row.className = "balance-row zero";
    row.innerHTML = '<span class="amt">—</span><span class="tok">No spendable balance found at the imported wallet. The seed may already be drained, or you may have entered the wrong seed.</span>';
    root.appendChild(row);
  } else {
    state.balances.forEach(b => {
      const row = document.createElement("div");
      row.className = "balance-row";
      const a = document.createElement("span");
      a.className = "amt";
      a.textContent = b.sendable;
      const t = document.createElement("span");
      t.className = "tok";
      t.textContent = b.name + (b.tokenid === "0x00" ? "" : "  (" + b.tokenid.slice(0, 14) + "…)");
      row.appendChild(a);
      row.appendChild(t);
      root.appendChild(row);
    });
  }

  $("confirm-verified").checked = false;
  $("confirm-final").checked = false;
  if ($("confirm-custom-dest")) $("confirm-custom-dest").checked = false;
  $("custom-dest-confirm-row").hidden = !state.customDest;

  $("sweep-results").innerHTML = "";
  $("sweep-next-row").hidden = true;
  setStatus("sweep-status", "");

  updateSweepEnabled();
}

function updateSweepEnabled() {
  const dest = getDestination();
  const destClash = !!dest && state.importedAddresses.indexOf(dest) >= 0;
  $("sweep-dest-warn").hidden = !destClash;

  const hasBalance = state.balances.length > 0;
  const baseChecks = $("confirm-verified").checked && $("confirm-final").checked;
  const customCheck = !state.customDest || $("confirm-custom-dest").checked;

  $("sweep-go-btn").disabled = !!(destClash || !hasBalance || !baseChecks || !customCheck);
}

function onCustomDestSet() {
  const v = ($("custom-dest-input").value || "").trim();
  if (!validMx(v)) {
    setStatus("sweep-status", "That doesn't look like a valid Minima address (Mx…).", "err");
    return;
  }
  state.customDest = v;
  $("sweep-dest").textContent = v;
  $("custom-dest-confirm-row").hidden = false;
  $("confirm-custom-dest").checked = false;
  setStatus("sweep-status", "Custom destination set: " + v + ".", "warn");
  updateSweepEnabled();
}

function onCustomDestClear() {
  state.customDest = null;
  $("sweep-dest").textContent = state.hostMx;
  $("custom-dest-confirm-row").hidden = true;
  $("confirm-custom-dest").checked = false;
  setStatus("sweep-status", "Reset destination to this node's address.", "ok");
  updateSweepEnabled();
}

async function onSweep() {
  const dest = getDestination();
  const root = $("sweep-results");
  root.innerHTML = "";
  $("sweep-go-btn").disabled = true;
  setStatus("sweep-status", "Sending…");
  let ok = 0, err = 0;
  for (const b of state.balances) {
    const row = document.createElement("div");
    row.className = "sweep-result";
    const lbl = document.createElement("span");
    lbl.className = "lbl";
    lbl.textContent = b.sendable + " " + b.name;
    const result = document.createElement("span");
    result.className = "result";
    result.textContent = "sending…";
    row.appendChild(lbl);
    row.appendChild(result);
    root.appendChild(row);
    try {
      const c = "send address:" + dest + " amount:" + b.sendable +
                (b.tokenid === "0x00" ? "" : " tokenid:" + b.tokenid);
      const r = await cmd(c);
      if (r.pending) {
        row.classList.add("ok");
        result.textContent = "pending — approve in MiniHub";
      } else {
        row.classList.add("ok");
        result.textContent = "sent";
      }
      ok++;
    } catch (e) {
      row.classList.add("err");
      result.textContent = "failed: " + e.message;
      err++;
    }
  }
  if (err === 0) {
    setStatus("sweep-status", "All " + ok + " transfer(s) submitted. Continue to restore your wallet.", "ok");
  } else {
    setStatus("sweep-status",
      ok + " ok, " + err + " failed. You can still continue to restore — but the failed token(s) remain at the compromised address; you may need to re-run recovery for them.",
      "err");
  }
  state.swept = true;
  $("sweep-next-row").hidden = false;
}

// ============================================================================
// STEP 5 — Restore (restoresync) + Verify
// ============================================================================

function appendRestoreLog(line) {
  const el = $("restore-log");
  el.textContent += line + "\n";
  el.scrollTop = el.scrollHeight;
}

async function onRestoreRun() {
  $("restore-run-btn").disabled = true;
  $("restore-success").hidden = true;
  $("restore-failure").hidden = true;
  setStatus("restore-status", "Running restoresync — this can take a minute…");
  $("restore-log").textContent = "";
  appendRestoreLog("> restoresync file:" + state.backupFile + " password:<hidden> host:" + state.selectedHost);
  try {
    const c = "restoresync file:" + state.backupFile +
              " password:" + state.backupPassword +
              " host:" + state.selectedHost;
    const r = await cmd(c);
    appendRestoreLog(JSON.stringify(r.response || r, null, 2));
    setStatus("restore-status", "Restore command returned. Verifying…", "ok");
    await new Promise(res => setTimeout(res, 2000));
    await runVerification();
  } catch (e) {
    appendRestoreLog("ERROR: " + e.message);
    setStatus("restore-status", "Restore failed: " + e.message, "err");
    $("restore-failure").hidden = false;
    $("restore-run-btn").disabled = false;
  }
}

async function runVerification() {
  $("verify-block").hidden = false;
  const root = $("verify-results");
  root.innerHTML = "";
  let allOk = true;

  // Check 1: getaddress should match the original hostMx
  const r1 = renderVerifyRow(root, "Default address matches original");
  try {
    const a = await cmd("getaddress");
    const got = ((a.response || {}).miniaddress || (a.response || {}).address || "");
    if (got === state.hostMx) {
      r1.pass("matches " + state.hostMx);
    } else {
      r1.fail("got " + got + ", expected " + state.hostMx);
      allOk = false;
    }
  } catch (e) {
    r1.fail(e.message);
    allOk = false;
  }

  // Check 2: balance is queryable
  const r2 = renderVerifyRow(root, "Wallet responsive");
  try {
    const b = await cmd("balance");
    const arr = Array.isArray(b.response) ? b.response : [];
    const minimaB = arr.find(x => x.tokenid === "0x00");
    r2.pass(minimaB
      ? "Minima sendable: " + (minimaB.sendable || minimaB.confirmed || "0")
      : "(no Minima entry yet — may take a few blocks)");
  } catch (e) {
    r2.fail(e.message);
    allOk = false;
  }

  if (allOk) {
    state.restored = true;
    $("restore-success").hidden = false;
    $("restore-failure").hidden = true;
    setStatus("restore-status", "Recovery complete.", "ok");
  } else {
    $("restore-failure").hidden = false;
    $("restore-success").hidden = true;
    setStatus("restore-status", "Verification did not match — see manual recovery instructions below.", "err");
  }
}

function renderVerifyRow(root, label) {
  const row = document.createElement("div");
  row.className = "verify-result";
  const lbl = document.createElement("span");
  lbl.className = "lbl";
  lbl.textContent = label;
  const result = document.createElement("span");
  result.className = "result";
  result.textContent = "checking…";
  row.appendChild(lbl);
  row.appendChild(result);
  root.appendChild(row);
  return {
    pass(msg) { row.classList.add("ok"); result.textContent = "✓ " + msg; },
    fail(msg) { row.classList.add("err"); result.textContent = "✗ " + msg; },
  };
}

// ============================================================================
// MEGAMMR HOST TAB
// ============================================================================

async function mmDetect() {
  setStatus("mm-detect-status", "Probing…");
  $("mm-detect-btn").disabled = true;
  try {
    await cmd("megammr action:info");
    setStatus("mm-detect-status", "MegaMMR mode is active on this node.", "ok");
    $("mm-download-btn").disabled = false;
  } catch (_e) {
    setStatus("mm-detect-status",
      "MegaMMR mode is NOT active. Restart your Minima node with -megammr in the startup arguments, then click Detect again.",
      "err");
    $("mm-download-btn").disabled = true;
  } finally {
    $("mm-detect-btn").disabled = false;
  }
}

async function mmDownload() {
  setStatus("mm-download-status", "Downloading " + MEGAMMR_FILE_URL + " — large file, please wait…");
  $("mm-download-btn").disabled = true;
  try {
    await new Promise((resolve, reject) => {
      MDS.file.download(MEGAMMR_FILE_URL, function (res) {
        if (res && res.status) resolve(res);
        else reject(new Error((res && res.error) || "download failed"));
      });
    });
    setStatus("mm-download-status", "Download complete. Saved to dapp folder.", "ok");
    $("mm-import-btn").disabled = false;
  } catch (e) {
    setStatus("mm-download-status", "Download failed: " + e.message, "err");
    $("mm-download-btn").disabled = false;
  }
}

async function mmImport() {
  setStatus("mm-import-status", "Importing — can take a few minutes for a large MMR file…");
  $("mm-import-btn").disabled = true;
  try {
    // MDS.file.download stores into the dapp's data folder, which is NOT the Minima
    // base folder. megammr action:import needs an absolute path.
    const fullPath = await new Promise((resolve, reject) => {
      MDS.file.getpath(MEGAMMR_LOCAL_FILENAME, function (res) {
        if (res && res.status) {
          const r = res.response || {};
          const path = r.path || r.fullpath || r.absolute || (typeof res.response === "string" ? res.response : null);
          if (path) return resolve(path);
        }
        reject(new Error("could not resolve absolute path for " + MEGAMMR_LOCAL_FILENAME));
      });
    });
    await cmd("megammr action:import file:" + fullPath);
    setStatus("mm-import-status",
      "Import complete. This node is now running a MegaMMR — once it finishes catching up, others can sync from it.",
      "ok");
  } catch (e) {
    setStatus("mm-import-status", "Import failed: " + e.message, "err");
    $("mm-import-btn").disabled = false;
  }
}

async function mmNetinfo() {
  $("mm-netinfo").textContent = "Loading…";
  try {
    const [maxR, , statusR] = await Promise.all([
      cmd("maxima action:info").catch(() => null),
      cmd("network action:list").catch(() => null),
      cmd("status").catch(() => null),
    ]);
    const lines = [];
    if (statusR && statusR.response && statusR.response.chain) {
      lines.push("chain top block: " + statusR.response.chain.block);
    }
    if (maxR && maxR.response) {
      const m = maxR.response;
      lines.push("maxima local: " + (m.local || m.contact || "(none)"));
      if (m.publickey) lines.push("maxima publickey: " + m.publickey);
    }
    lines.push("");
    lines.push("DM these details to @eurobuddha to be added to the Recovery host pool.");
    $("mm-netinfo").textContent = lines.join("\n") || "(no info available)";
  } catch (e) {
    $("mm-netinfo").textContent = "Failed: " + e.message;
  }
}

// ============================================================================
// Wiring
// ============================================================================

function wireUp() {
  // Tabs
  document.querySelectorAll(".tab").forEach(t =>
    t.addEventListener("click", () => showTab(t.dataset.tab)));

  // Step 0 — welcome
  $("welcome-start-btn").addEventListener("click", onWelcomeStart);

  // Step 1 — snapshot
  $("snap-back-btn").addEventListener("click", () => show("welcome"));
  $("snap-paper-check").addEventListener("change", updateSnapshotEnabled);
  $("snap-pw-check").addEventListener("change", updateSnapshotEnabled);
  $("snap-backup-btn").addEventListener("click", onSnapBackup);
  $("snap-copyseed-btn").addEventListener("click", () =>
    copyText(state.hostSeed).then(ok =>
      flashStatus("snap-backup-status", ok ? "Copied seed (wipe clipboard after pasting on paper)." : "Copy failed.")));
  $("snap-copymx-btn").addEventListener("click", () =>
    copyText(state.hostMx).then(ok =>
      flashStatus("snap-backup-status", ok ? "Copied address." : "Copy failed.")));
  $("snap-copypw-btn").addEventListener("click", () =>
    copyText(state.backupPassword).then(ok =>
      flashStatus("snap-backup-status", ok ? "Copied password (write it on paper, don't leave on clipboard)." : "Copy failed.")));
  $("snap-continue-btn").addEventListener("click", () => show("seed"));

  // Step 2 — paste compromised seed
  $("seed-back-btn").addEventListener("click", () => show("snapshot"));
  $("seed-continue-btn").addEventListener("click", onSeedContinue);

  // Step 3 — sync
  $("rotate-host-btn").addEventListener("click", rotateHost);
  $("custom-host-set-btn").addEventListener("click", onCustomHostSet);
  $("sync-back-btn").addEventListener("click", () => show("seed"));
  $("sync-run-btn").addEventListener("click", onRunSync);

  // Step 4 — sweep
  $("confirm-verified").addEventListener("change", updateSweepEnabled);
  $("confirm-final").addEventListener("change", updateSweepEnabled);
  $("confirm-custom-dest").addEventListener("change", updateSweepEnabled);
  $("custom-dest-set-btn").addEventListener("click", onCustomDestSet);
  $("custom-dest-clear-btn").addEventListener("click", onCustomDestClear);
  $("sweep-back-btn").addEventListener("click", () => show("sync"));
  $("sweep-go-btn").addEventListener("click", onSweep);
  $("sweep-next-btn").addEventListener("click", () => show("finish"));

  // Step 5 — restore
  $("restore-run-btn").addEventListener("click", onRestoreRun);
  $("finish-restart-btn").addEventListener("click", () => location.reload());

  // MegaMMR tab
  $("mm-detect-btn").addEventListener("click", mmDetect);
  $("mm-download-btn").addEventListener("click", mmDownload);
  $("mm-import-btn").addEventListener("click", mmImport);
  $("mm-netinfo-btn").addEventListener("click", mmNetinfo);
  $("mm-netinfo-copy-btn").addEventListener("click", () =>
    copyText($("mm-netinfo").textContent).then(ok =>
      flashStatus("mm-detect-status", ok ? "Copied." : "Copy failed.")));
}

document.addEventListener("DOMContentLoaded", wireUp);

MDS.init(function (msg) {
  if (msg.event === "inited") {
    show("welcome");
    showTab("recover");
  }
});
